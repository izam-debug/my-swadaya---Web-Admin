<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\TagihanController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layout.login');
});
// Route::get('/admin', function () {
//     return view('layout.login');
// })->middleware('guest');
Route::get('/dashboard', function () {
    return view('layout.dashboard');
})->middleware('auth');
// Route::get('/air', function () {
//     return view('layout.master-air');
// });
// Route::get('/master/data-pelanggan', function () {
//     return view('layout.master-pelanggan');
// });

Route::get('/', [ClientController::class, 'loginForm'])->name('login-client');
Route::post('/login', [AuthController::class, 'authenticate']);
Route::post('/logout', [AuthController::class, 'logout']);
Route::get('/master/data-pelanggan', [ClientController::class, 'index'])->name('master-client')->middleware('auth');
Route::get('/master/data-petugas', [AuthController::class, 'list_petugas'])->name('master-petugas')->middleware('auth');
Route::post('/add/client', [ClientController::class, 'add_client']);
Route::post('/add/petugas', [AuthController::class, 'add_petugas']);
Route::post('/update/client', [ClientController::class, 'update_client']);
Route::post('/update/petugas', [AuthController::class, 'update_petugas']);
Route::post('/update-harga-air', [TagihanController::class, 'update_harga']);
Route::get('/clients/{id}/edit', [ClientController::class, 'edit_client']);
Route::get('/petugas/{id}/edit', [AuthController::class, 'edit_petugas']);
Route::get('/clients/{id}/delete', [ClientController::class, 'delete_client']);
Route::get('/petugas/{id}/delete', [AuthController::class, 'delete_petugas']);
Route::post('/client/login', [ClientController::class, 'authenticate']);
Route::get('/master/harga-air', [TagihanController::class, 'harga_air'])->name('master-air')->middleware('auth');
Route::post('/api/insert-data-tagihan', [TagihanController::class, 'insert']);
Route::get('/api/get-data-tagihan', [TagihanController::class, 'get']);
Route::post('/api/user', [AuthController::class, 'apiLogin']);
Route::get('/client-dashboard', [ClientController::class, 'dashboard'])->name('client-dashboard');
Route::get('/siarkan', [TagihanController::class, 'siarkan_tagihan']);
Route::get('/tagihan', [TagihanController::class, 'index_tagihan']);
Route::get('/tagihan/{id}/bayar', [TagihanController::class, 'bayar_tagihan']);
