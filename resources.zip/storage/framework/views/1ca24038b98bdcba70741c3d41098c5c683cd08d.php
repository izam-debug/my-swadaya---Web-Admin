
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="http://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.bootstrap5.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Daftar Tagihan Pelanggan (Sudah Disiarkan)</h2>
    </div>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="card-body">
        
        <table class="table table-striped" style="width: 100%;" id="tabel_pelanggan">
            <thead>
                <tr>
                    <td>#</td>
                    <td>Nama Pelanggan</td>
                    <td>Pemakaian</td>
                    <td>Total Tagihan</td>
                    <td>Status Tagihan</td>
                    <td>Aksi</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tg->nama_client); ?></td>
                    <td><?php echo e($tg->pemakaian); ?></td>
                    <td><?php echo e(number_format($tg->tagihan, 0, ',', '.')); ?></td>
                    <td>
                        <?php if($tg->status_tagihan == "Dibayar"): ?>
                        <label class="badge badge-success" style="color: black;">Sudah Dibayar</label>
                        <?php else: ?>
                        <label class="badge badge-danger" style="color: black;">Belum Dibayar</label>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($tg->status_tagihan == "Belum Dibayar"): ?>
                        <button class="btn btn-primary btn-rounded btn-fw update_bayar" style="color: white;" onclick="confirmBayar(<?php echo e($tg->id); ?>)" title="Tagihan Dibayar"><i class="bi bi-cash-coin"></i></button>
                        <?php else: ?>
                        <button class="btn btn-success btn-rounded btn-fw cetak_kwitansi" style="color: white;" title="Cetak Kwitansi"><i class="bi bi-printer"></i></button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/2.0.2/js/dataTables.min.js"></script>
<script>
    function confirmBayar(id) {
        Swal.fire({
            title: 'Konfirmasi Bayar',
            text: 'Apakah Anda yakin ingin mengubah status data ini menjadi DIBAYAR?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yakin!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika pengguna mengonfirmasi, arahkan ke rute penghapusan
                window.location.href = '/tagihan/' + id + '/bayar';
            }
        });
    }
</script>
<script>
    $(document).ready(function () {
        $('.edit_client').click(function () {
            var clientId = $(this).data('client-id');

            // Ajax request untuk mengambil data client berdasarkan ID
            $.ajax({
                url: '/clients/' + clientId + '/edit',
                method: 'GET',
                success: function (data) {
                    $('#id_client').val(data.id);
                    $('#edit_nama').val(data.nama_client);
                    $('#edit_username').val(data.username);
                    $('#edit_no_whatsapp').val(data.no_whatsapp);
                    $('#editModal').modal('show');
                    console.log(data);
                },
                error: function (error) {
                    console.error('Error fetching client data:', error);
                }
            });
        });
    });

    let table = new DataTable('#tabel_pelanggan');
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tagihan-air\resources\views/layout/tagihan.blade.php ENDPATH**/ ?>