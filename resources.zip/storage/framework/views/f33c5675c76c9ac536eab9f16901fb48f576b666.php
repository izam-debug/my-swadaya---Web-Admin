
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Dashboard</h2>
    </div>
    <div class="card-body">
        ini dashboard client
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template-client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tagihan-air\resources\views/layout/dashboard-client.blade.php ENDPATH**/ ?>