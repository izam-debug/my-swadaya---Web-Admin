@extends('template')
@section('content')
<div class="card">
    <div class="card-header">
        <h2>Dashboard</h2>
    </div>
    <div class="card-body">
        ini dashboard administrator
    </div>
</div>
@endsection