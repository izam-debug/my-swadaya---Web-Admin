<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Air extends Model
{
    use HasFactory;
    protected $table = 'harga_air';

    // public function harga_air()
    // {
    //     $harga = 10000;
    //     return($harga);
    // }
}
