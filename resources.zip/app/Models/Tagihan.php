<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tagihan extends Model
{
    use HasFactory;

    protected $table = 'tagihan';
    protected $fillable = [
        'kode_client',
        'id_petugas',
        'nomor_meter',
        'pemakaian',
        'tagihan',
        'status_tagihan',
    ];

    public function index_tagihan()
    {
        return $this->join('client', 'client.kode_client','=', 'tagihan.kode_client')
                    // ->where('tagihan.status_tagihan', '=', 'Belum Disiarkan')
                    ->select('client.nama_client', 'tagihan.*')
                    ->get();
    }
}
