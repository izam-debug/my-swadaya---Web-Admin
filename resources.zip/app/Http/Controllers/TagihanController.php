<?php

namespace App\Http\Controllers;

use App\Models\Air;
use App\Models\Client;
use App\Models\Tagihan;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Firebase\JWT\JWT;

class TagihanController extends Controller
{
    public function harga_air()
    {
        // $harga = file_get_contents('harga-air.txt');
        // return view('layout.master-air', compact('harga'));
        $harga = Air::pluck('harga')->first();
        return view('layout.master-air', compact('harga'));
    }

    public function update_harga(Request $request)
    {
        $harga_baru = $request->input('harga_air');
        // file_put_contents('harga-air.txt', $harga_baru);
        $harga = Air::first();
        $harga->harga = $harga_baru;
        $harga->update();
        return redirect()->route('master-air')->with('success', 'Harga Air Berhasil Diubah.');
    }

    public function insert(Request $request)
    {
        $token = $request->input('token');
    
        // Cek apakah token ada
        if (!$token) {
            return response()->json(['message' => 'Token not provided'], 401);
        }
    
        // Cek kebenaran token dengan data user pada database
        $user = User::where('token', $token)->first();
        if (!$user) {
            return response()->json(['message' => 'Invalid token'], 401);
        }
    
        // Lakukan validasi terhadap data yang diterima
        $validator = Validator::make($request->all(), [
            'kode_client' => 'required',
            'nomor_meter' => 'required|numeric',
            'id_petugas' => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['message' => 'Invalid data', 'errors' => $validator->errors()], 400);
        }
    
        // Ambil nomor meter terakhir yang disimpan
        $pelanggan = $request->input('kode_client');

        $kode = Client::where('kode_client', $pelanggan)->first();

        if(!$kode) {
            return response()->json('Pelanggan tidak ditemukan', 400);
        }

        $tagihanTerakhir = Tagihan::where('kode_client', $pelanggan)
            ->whereMonth('created_at', now()->month) // Mencari tagihan untuk bulan ini
            ->orderBy('created_at', 'desc')
            ->first();
        
        $nomorMeterTerakhir = Tagihan::where('kode_client', $pelanggan)
            ->orderBy('created_at', 'desc')
            ->pluck('nomor_meter')
            ->first();

        if(!$nomorMeterTerakhir) {
            return response()->json('Belum ada tagihan sebelumnya', 400);
        }

        if ($tagihanTerakhir) {
            return response()->json('Tagihan untuk bulan ini sudah ada', 400);
        }
    
        // Ambil nomor meter terakhir yang disimpan
        $nomorMeterSekarang = $request->input('nomor_meter');
    
        // Ambil harga air
        $hargaAir = Air::first();
        $tagihanBaru = new Tagihan();
        $tagihanBaru->kode_client = $pelanggan;
        $tagihanBaru->id_petugas = $request->input('id_petugas');
        $tagihanBaru->nomor_meter = $nomorMeterSekarang;
        $tagihanBaru->pemakaian = $nomorMeterSekarang - $nomorMeterTerakhir;
        $tagihanBaru->tagihan = $tagihanBaru->pemakaian * $hargaAir->harga;
        $tagihanBaru->save();
    
        return response()->json('Data berhasil disimpan');
    }

    public function get()
    {
        $tagihan = Tagihan::all();
        return response()->json($tagihan, 200, [], JSON_PRETTY_PRINT);
    }

    public function siarkan_tagihan()
    {
        $daftar_tagihan = new Tagihan();
        $tagihan = $daftar_tagihan->index_tagihan()
                                  ->where('status_tagihan', '=', 'Belum Disiarkan');

        return view('layout.siarkan', compact('tagihan'));
    }

    public function index_tagihan()
    {
        $daftar_tagihan = new Tagihan();
        $tagihan = $daftar_tagihan->index_tagihan()
                                  ->where('status_tagihan', '!=', 'Belum Disiarkan');

        return view('layout.tagihan', compact('tagihan'));
    }

    public function bayar_tagihan($id)
    {
        $tagihan = Tagihan::find($id);
        $tagihan->status_tagihan = "Dibayar";
        $tagihan->update();
        return redirect()->back();
    }
}
