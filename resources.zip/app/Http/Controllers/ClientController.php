<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\RedirectResponse;

class ClientController extends Controller
{
    public function index()
    {
        $client = Client::all();
        return view('layout.master-pelanggan', compact('client'));
    }

    public function add_client(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required|string|max:255',
            'username' => 'required|string|alpha_dash|max:10|unique:client',
            'password' => '',
            'no_whatsapp' => 'required|numeric!max:13',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // Simpan data ke dalam tabel clients
        $kode = Client::generateUniqueCode();
        $password = $request->input('password') ? bcrypt($request->input('password')) : bcrypt('pelanggan123');
        $client = new Client([
            'nama_client' => $request->input('nama'),
            'username' => $request->input('username'),
            'password' => $password,
            'no_whatsapp' => $request->input('no_whatsapp'),
            'kode_client' => $kode,
        ]);
        $client->save();
        return redirect()->route('master-client')->with('success', 'Data berhasil disimpan.');
    }
    public function edit_client($id)
    {
        $client = Client::findorfail($id);
        return response()->json($client);
    }
    public function update_client(Request $request)
    {
        $id = $request->input('id_client');
        $validator = Validator::make($request->all(), [
            'nama' => 'required|string|max:255',
            'username' => 'required|string|alpha_dash|max:10|unique:client,username,' . $id,
            'password' => 'required|string|min:6',
            'no_whatsapp' => 'required|numeric|digits:10',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        // Simpan data ke dalam tabel clients
        $kode = Client::generateUniqueCode();
       
        $client = Client::find($id);
        $client->nama_client = $request->input('nama');
        $client->username = $request->input('username');
        if ($request->filled('password')) {
            $client->password = bcrypt($request->input('password'));
        }
        $client->no_whatsapp = $request->input('no_whatsapp');
        $client->update();
        return redirect()->route('master-client')->with('success', 'Data berhasil diedit.');
    }

    public function delete_client($id)
    {
        $client = Client::findOrFail($id);
        $client->delete();
    
        return redirect()->route('master-client')->with('success', 'Data berhasil dihapus.');
    }

    protected $username = 'username';
    public function username()
    {
        return 'username';
    }

    public function loginForm()
    {
       
        if (Auth::guard('client')->check()) {
            return redirect()->route('client-dashboard');
        }

        // Jika belum, tampilkan halaman login
        return view('layout.client-login');
    }

    public function authenticate(Request $request): RedirectResponse
    {
        $credentials = $request->only('username', 'password');

        if (Auth::guard('client')->attempt($credentials)) {
            // Jika autentikasi berhasil, redirect ke dashboard client
            return redirect()->route('client-dashboard');
        }

        // Jika autentikasi gagal, kembali ke halaman login dengan pesan error
        return back()->with('loginError', 'Email atau password salah');

    }

    public function dashboard()
    {
        if (Auth::guard('client')->check()) {
            return view('layout.dashboard-client');
        }

        return redirect()->route('login-client')->with('loginError', 'Silakan login terlebih dahulu.');
    }

    
}
