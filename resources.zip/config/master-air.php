<?php
    return [
        'harga_air' => 10000,
    ];
?>